// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @notice The parts of PropertyRegistry (SmartContract.sol) that this contract reads.
interface IPropertyRegistry {
    function registrar() external view returns (address);

    function getProperty(string memory propertyId)
        external
        view
        returns (
            address propertyOwner,
            uint8 propertyType,
            uint256 registeredAt,
            uint256 transfersDone,
            uint256 totalFeesWei,
            uint256 unpaidNotices
        );
}

/// @title Property Inspection Log (bonus contract, Assignment 3)
/// @notice A second contract that works alongside PropertyRegistry. Approved municipal
///         inspectors record site inspections against registered properties.
/// @dev Shows contract-to-contract interaction: every inspection calls the registry
///      on-chain to confirm the property exists (getProperty reverts if it does not)
///      and to snapshot the owner at the time of inspection. Inspector management is
///      restricted to the same registrar that deployed PropertyRegistry.
contract PropertyInspection {

    IPropertyRegistry public immutable registry;

    struct Inspection {
        string propertyId;
        address inspector;
        address ownerAtInspection;
        uint8 result;             // 0 = Compliant, 1 = Minor issues, 2 = Major violation
        string remarks;
        uint256 timestamp;
    }

    uint256 public inspectionCount;
    mapping(uint256 => Inspection) public inspections;          // ids start at 1
    mapping(address => bool) public isInspector;
    mapping(string => uint256[]) private inspectionsByProperty;

    event InspectorUpdated(address indexed inspector, bool allowed);
    event InspectionRecorded(uint256 indexed inspectionId, string propertyId, address indexed inspector, uint8 result);

    constructor(address registryAddress) {
        require(registryAddress != address(0), "Registry address required");
        registry = IPropertyRegistry(registryAddress);
    }

    /// @notice Registrar approves or removes an inspector wallet.
    function setInspector(address inspector, bool allowed) external {
        require(msg.sender == registry.registrar(), "Only the registrar can manage inspectors");
        require(inspector != address(0), "Invalid inspector address");
        isInspector[inspector] = allowed;
        emit InspectorUpdated(inspector, allowed);
    }

    /// @param propertyId Registered property reference (checked against the registry)
    /// @param result 0 = Compliant, 1 = Minor issues, 2 = Major violation
    /// @param remarks Short note from the inspector (max 140 characters)
    function recordInspection(string memory propertyId, uint8 result, string memory remarks) external {
        require(
            isInspector[msg.sender] || msg.sender == registry.registrar(),
            "Only an approved inspector can record inspections"
        );
        require(result < 3, "Invalid inspection result");
        require(bytes(remarks).length <= 140, "Remarks must be 140 characters or less");

        // Cross-contract call: reverts with "Property not registered" if the ID is unknown
        (address currentOwner, , , , , ) = registry.getProperty(propertyId);

        inspectionCount += 1;
        inspections[inspectionCount] = Inspection({
            propertyId: propertyId,
            inspector: msg.sender,
            ownerAtInspection: currentOwner,
            result: result,
            remarks: remarks,
            timestamp: block.timestamp
        });
        inspectionsByProperty[propertyId].push(inspectionCount);

        emit InspectionRecorded(inspectionCount, propertyId, msg.sender, result);
    }

    /// @notice All inspection ids recorded for a property (oldest first). Free view call.
    function getInspectionIds(string memory propertyId) external view returns (uint256[] memory) {
        return inspectionsByProperty[propertyId];
    }
}
