/* =====================================================================
   Property Registry dApp — frontend logic (ethers.js v6 + MetaMask)
   MG3012 Assignment 3 · Truffle + Ganache

   The ABI and deployed address are read from Truffle's build artifacts
   (build/contracts/*.json), so the page always talks to whatever
   `truffle migrate` last deployed on the current network.
   ===================================================================== */

const GANACHE = {
  chainIdHex: "0x539",              // 1337
  rpcUrl: "http://127.0.0.1:7545",
  name: "Ganache Local",
};

// server.js serves build/contracts at /contracts. The second path works when the
// project root is served instead (e.g. VS Code Live Server opening frontend/index.html).
const ARTIFACT_PATHS = ["/contracts/", "../build/contracts/"];

const PROPERTY_TYPES = ["Residential Plot", "House", "Commercial"];
const ZONES = ["Islamabad", "Rawalpindi", "Lahore"];
const NOTICE_TYPES = ["Unpaid property tax", "Illegal construction", "Encroachment"];
const INSPECTION_RESULTS = ["Compliant", "Minor issues", "Major violation"];
const RESULT_CHIPS = ["chip-ok", "chip-warn", "chip-bad"];

const state = {
  provider: null,
  signer: null,
  account: null,
  netId: null,
  registryRead: null,     // read-only contract (provider)
  registry: null,         // contract connected to the signer (for transactions)
  inspectionRead: null,
  inspection: null,
  registrar: null,
  isInspector: false,
  fees: null,             // { zone: [], mult: [], fine: [], maxNotices }
  blockTimes: new Map(),
  currentLookup: null,
  refreshing: false,
};

/* ---------------- small helpers ---------------- */
const $ = (id) => document.getElementById(id);
const short = (a) => (a ? `${a.slice(0, 6)}…${a.slice(-4)}` : "—");
const sameAddr = (a, b) => !!a && !!b && a.toLowerCase() === b.toLowerCase();
const normId = (s) => s.trim().toUpperCase();
const fmtEth = (wei, dp) => {
  const s = ethers.formatEther(wei);
  return `${dp === undefined ? s : Number(s).toFixed(dp)} ETH`;
};
const escapeHtml = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtTime = (sec) =>
  new Date(Number(sec) * 1000).toLocaleString("en-GB", {
    day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
const who = (addr) => {
  let label = short(addr);
  if (sameAddr(addr, state.account)) label += " (you)";
  else if (sameAddr(addr, state.registrar)) label += " (registrar)";
  return `<span class="mono" title="${addr}">${label}</span>`;
};
function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/* ---------------- banner + toasts ---------------- */
function showBanner(msg, isError = false) {
  const b = $("banner");
  b.textContent = msg;
  b.className = `banner${isError ? " error" : ""}`;
}
function hideBanner() { $("banner").className = "banner hidden"; }

function toast(title, body, kind = "ok", ttl = 6000) {
  const el = document.createElement("div");
  el.className = `toast ${kind}`;
  el.innerHTML = `<strong>${escapeHtml(title)}</strong><div class="mono">${escapeHtml(body)}</div>`;
  $("toasts").appendChild(el);
  if (ttl) setTimeout(() => el.remove(), ttl);
  return el;
}
function updateToast(el, title, body, kind, ttl) {
  el.className = `toast ${kind}`;
  el.innerHTML = `<strong>${escapeHtml(title)}</strong><div class="mono">${escapeHtml(body)}</div>`;
  if (ttl) setTimeout(() => el.remove(), ttl);
}

// Dig the require() message out of an error. MetaMask, Ganache and ethers all
// wrap it differently, so search the whole error object for it.
function findRevertReason(err) {
  const seen = new Set();
  const stack = [err];
  while (stack.length) {
    const v = stack.pop();
    if (v === null || v === undefined) continue;
    if (typeof v === "string") {
      if (/^0x08c379a0/i.test(v)) {   // ABI-encoded Error(string)
        try { return ethers.AbiCoder.defaultAbiCoder().decode(["string"], "0x" + v.slice(10))[0]; } catch (_) {}
      }
      const m = v.match(/(?:VM Exception while processing transaction: revert|execution reverted:|reverted with reason string)\s*["']?([^"'\\\n(][^"'\\\n]*)/i);
      if (m && m[1].trim()) return m[1].trim();
      continue;
    }
    if (typeof v !== "object" || seen.has(v)) continue;
    seen.add(v);
    if (typeof v.reason === "string" && v.reason && v.reason !== "revert") return v.reason;
    for (const key of Object.getOwnPropertyNames(v)) {
      try { stack.push(v[key]); } catch (_) {}
    }
  }
  return null;
}

// Turn ethers / MetaMask errors into a readable message
function errMsg(e) {
  if (e?.code === "ACTION_REJECTED" || e?.code === 4001 || e?.info?.error?.code === 4001) {
    return "Transaction rejected in MetaMask.";
  }
  return findRevertReason(e) || e?.shortMessage || e?.message || String(e);
}

/* ---------------- start-up ---------------- */
async function init() {
  wireForms();

  if (window.ethereum) {
    state.provider = new ethers.BrowserProvider(window.ethereum);
    window.ethereum.on?.("accountsChanged", onAccountsChanged);
    window.ethereum.on?.("chainChanged", () => window.location.reload());
  } else {
    // No MetaMask: still show data by reading straight from Ganache
    state.provider = new ethers.JsonRpcProvider(GANACHE.rpcUrl);
    showBanner("MetaMask not detected — read-only mode (reading from Ganache at 127.0.0.1:7545). Install MetaMask to send transactions.");
    $("connectBtn").disabled = true;
  }

  const loaded = await loadContracts();
  if (loaded) await refreshAll();

  // Reconnect silently if this site is already authorised in MetaMask
  if (window.ethereum) {
    const accounts = await window.ethereum.request({ method: "eth_accounts" });
    if (accounts.length) await connect(false);
  }

  if (loaded) state.provider.on("block", debounce(refreshAll, 300));
}

async function fetchArtifact(name) {
  for (const base of ARTIFACT_PATHS) {
    try {
      const res = await fetch(`${base}${name}.json`, { cache: "no-store" });
      if (res.ok) return await res.json();
    } catch (_) { /* try next path */ }
  }
  throw new Error(`Could not load ${name}.json. Run "truffle migrate" first, then start the site with "npm run frontend".`);
}

async function loadContracts() {
  try {
    const [regArtifact, inspArtifact] = await Promise.all([
      fetchArtifact("PropertyRegistry"),
      fetchArtifact("PropertyInspection").catch(() => null),
    ]);

    state.netId = String(await state.provider.send("net_version", []));
    const regNet = regArtifact.networks[state.netId];
    if (!regNet) {
      setNetworkPill(false);
      showBanner(
        `PropertyRegistry is not deployed on network ${state.netId}. Start Ganache, run "truffle migrate", ` +
        `and switch MetaMask to "${GANACHE.name}" (RPC ${GANACHE.rpcUrl}, chain id 1337).`,
        true
      );
      return false;
    }

    state.registryRead = new ethers.Contract(regNet.address, regArtifact.abi, state.provider);
    $("statContract").textContent = short(regNet.address);
    $("statContract").title = regNet.address;

    const inspNet = inspArtifact?.networks?.[state.netId];
    if (inspNet) {
      state.inspectionRead = new ethers.Contract(inspNet.address, inspArtifact.abi, state.provider);
      $("inspContract").textContent = short(inspNet.address);
      $("inspContract").title = inspNet.address;
    }

    setNetworkPill(true);
    hideBanner();
    return true;
  } catch (e) {
    showBanner(e.message, true);
    return false;
  }
}

function setNetworkPill(ok) {
  const pill = $("networkPill");
  pill.className = `pill ${ok ? "pill-ok" : "pill-bad"}`;
  pill.textContent = ok ? `Ganache · network ${state.netId}` : `Wrong network (${state.netId})`;
}

/* ---------------- wallet ---------------- */
async function ensureGanacheNetwork() {
  const chainId = await window.ethereum.request({ method: "eth_chainId" });
  if (chainId === GANACHE.chainIdHex) return true;
  try {
    await window.ethereum.request({ method: "wallet_switchEthereumChain", params: [{ chainId: GANACHE.chainIdHex }] });
  } catch (err) {
    if (err.code === 4902) {
      await window.ethereum.request({
        method: "wallet_addEthereumChain",
        params: [{
          chainId: GANACHE.chainIdHex,
          chainName: GANACHE.name,
          rpcUrls: [GANACHE.rpcUrl],
          nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
        }],
      });
    } else {
      throw err;
    }
  }
  return false; // page reloads on chainChanged
}

async function connect(ask = true) {
  if (!window.ethereum) return;
  try {
    const accounts = await window.ethereum.request({ method: ask ? "eth_requestAccounts" : "eth_accounts" });
    if (!accounts.length) return;
    if (!(await ensureGanacheNetwork())) return;
    if (!state.registryRead) return;

    state.account = ethers.getAddress(accounts[0]);
    state.signer = await state.provider.getSigner(state.account);
    state.registry = state.registryRead.connect(state.signer);
    if (state.inspectionRead) state.inspection = state.inspectionRead.connect(state.signer);

    $("connectBtn").textContent = "Connected";
    $("connectBtn").disabled = true;
    const pill = $("accountPill");
    pill.textContent = short(state.account);
    pill.title = state.account;
    pill.className = "pill pill-acct";

    await refreshAll();
    toast("Wallet connected", state.account);
  } catch (e) {
    toast("Could not connect", errMsg(e), "error", 8000);
  }
}

async function onAccountsChanged(accounts) {
  if (!accounts.length) {
    state.account = state.signer = state.registry = state.inspection = null;
    $("connectBtn").textContent = "Connect MetaMask";
    $("connectBtn").disabled = false;
    $("accountPill").className = "pill pill-muted hidden";
    await refreshAll();
  } else {
    await connect(false);
  }
}

/* ---------------- sending transactions ---------------- */
async function sendTx(label, send) {
  if (!state.signer) {
    toast("Connect MetaMask first", "Use the Connect MetaMask button (top right).", "error");
    return null;
  }
  const t = toast(`${label}…`, "Waiting for MetaMask confirmation", "pending", 0);
  try {
    const tx = await send();
    updateToast(t, `${label} — submitted`, `tx ${tx.hash}`, "pending");
    const receipt = await tx.wait();
    updateToast(
      t,
      `${label} — confirmed ✔`,
      `block #${receipt.blockNumber} · gas used ${receipt.gasUsed.toString()} · tx ${tx.hash}`,
      "ok",
      9000
    );
    await refreshAll();
    return receipt;
  } catch (e) {
    updateToast(t, `${label} — failed`, errMsg(e), "error", 9000);
    return null;
  }
}

/* ---------------- refresh (reads) ---------------- */
async function refreshAll() {
  if (!state.registryRead || state.refreshing) return;
  state.refreshing = true;
  try {
    await refreshStats();
    await loadFees();
    await refreshActivity();
    if (state.currentLookup) await showProperty(state.currentLookup, true);
    await Promise.all([updateFeeQuote(), updateNoticePreview(), updateNoticeFine()]);
  } catch (e) {
    console.error(e);
  } finally {
    state.refreshing = false;
  }
}

async function refreshStats() {
  const r = state.registryRead;
  const [registrar, transfers, notices, block] = await Promise.all([
    r.registrar(), r.transferCount(), r.noticeCount(), state.provider.getBlockNumber(),
  ]);
  state.registrar = registrar;

  $("statRegistrar").textContent = short(registrar);
  $("statRegistrar").title = registrar;
  $("statTreasury").textContent = `Treasury balance ${fmtEth(await state.provider.getBalance(registrar), 4)}`;
  $("statTransfers").textContent = transfers.toString();
  $("statNotices").textContent = notices.toString();
  $("statBlock").textContent = `Network ${state.netId} · latest block #${block}`;

  state.isInspector = false;
  if (state.account && state.inspectionRead) {
    state.isInspector = await state.inspectionRead.isInspector(state.account);
  }

  const isRegistrar = sameAddr(state.account, registrar);
  if (state.account) {
    $("statRole").textContent = isRegistrar ? "Registrar" : state.isInspector ? "Inspector" : "Citizen / owner";
    $("statBalance").textContent = `${short(state.account)} · ${fmtEth(await state.provider.getBalance(state.account), 4)}`;
  } else {
    $("statRole").textContent = "Visitor";
    $("statBalance").textContent = "Connect a wallet to transact";
  }

  // Registrar-only notice form
  const lock = !isRegistrar;
  for (const el of $("noticeForm").elements) el.disabled = lock;
  $("registrarOnlyMsg").classList.toggle("hidden", !lock);
  $("registrarOnlyMsg").textContent = state.account
    ? "Only the registrar can issue notices. Switch MetaMask to Ganache account 0 (the deployer)."
    : "Connect MetaMask with the registrar account (Ganache account 0) to issue notices.";

  // Bonus contract controls
  $("inspectorForm").classList.toggle("hidden", !isRegistrar);
  const canInspect = isRegistrar || state.isInspector;
  for (const el of $("inspectionForm").elements) el.disabled = !canInspect || !state.inspectionRead;
  const status = $("inspStatus");
  if (!state.inspectionRead) { status.textContent = "not deployed"; status.className = "chip chip-bad"; }
  else if (isRegistrar) { status.textContent = "Registrar (can inspect)"; status.className = "chip chip-bonus"; }
  else if (state.isInspector) { status.textContent = "Approved inspector"; status.className = "chip chip-ok"; }
  else { status.textContent = state.account ? "Not an inspector" : "Not connected"; status.className = "chip"; }
}

async function loadFees() {
  if (state.fees) return;
  const r = state.registryRead;
  const idx = [0, 1, 2];
  const [zone, mult, fine, maxNotices] = await Promise.all([
    Promise.all(idx.map((i) => r.zoneBaseFee(i))),
    Promise.all(idx.map((i) => r.typeMultiplier(i))),
    Promise.all(idx.map((i) => r.noticeFine(i))),
    r.MAX_UNPAID_NOTICES(),
  ]);
  state.fees = { zone, mult, fine, maxNotices };

  $("feeTable").querySelector("tbody").innerHTML = ZONES.map(
    (z, zi) => `<tr><td>${z} <span class="muted small">(base ${fmtEth(zone[zi])})</span></td>${
      idx.map((t) => `<td>${fmtEth(zone[zi] * mult[t])}</td>`).join("")
    }</tr>`
  ).join("");
  $("fineTable").querySelector("tbody").innerHTML = NOTICE_TYPES.map(
    (n, i) => `<tr><td>${n}</td><td>${fmtEth(fine[i])}</td></tr>`
  ).join("");
  $("maxNotices").textContent = maxNotices.toString();
}

async function blockTime(n) {
  if (!state.blockTimes.has(n)) {
    const b = await state.provider.getBlock(n);
    state.blockTimes.set(n, b.timestamp);
  }
  return state.blockTimes.get(n);
}

function describeEvent(ev) {
  const a = ev.args;
  switch (ev.eventName) {
    case "PropertyRegistered":
      return `<strong>${escapeHtml(a.propertyId)}</strong> registered as ${PROPERTY_TYPES[a.propertyType]} by ${who(a.propertyOwner)}`;
    case "PropertyTransferred":
      return `Transfer #${a.transferId} · <strong>${escapeHtml(a.propertyId)}</strong> ${who(a.from)} → ${who(a.to)} · ${ZONES[a.zone]} · fee ${fmtEth(a.amount)}`;
    case "NoticeIssued":
      return `Notice #${a.noticeId} · ${NOTICE_TYPES[a.noticeType]} on <strong>${escapeHtml(a.propertyId)}</strong> · fine ${fmtEth(a.fine)}`;
    case "NoticePaid":
      return `Notice #${a.noticeId} on <strong>${escapeHtml(a.propertyId)}</strong> paid by ${who(a.payer)} · ${fmtEth(a.amount)}`;
    case "InspectorUpdated":
      return `${who(a.inspector)} ${a.allowed ? "approved" : "removed"} as inspector`;
    case "InspectionRecorded":
      return `Inspection #${a.inspectionId} · <strong>${escapeHtml(a.propertyId)}</strong> · ${INSPECTION_RESULTS[a.result]} · by ${who(a.inspector)}`;
    default:
      return ev.eventName;
  }
}

async function refreshActivity() {
  const sources = [
    [state.registryRead, ["PropertyRegistered", "PropertyTransferred", "NoticeIssued", "NoticePaid"]],
  ];
  if (state.inspectionRead) sources.push([state.inspectionRead, ["InspectorUpdated", "InspectionRecorded"]]);

  const logs = [];
  for (const [contract, names] of sources) {
    for (const name of names) logs.push(...(await contract.queryFilter(name, 0, "latest")));
  }
  logs.sort((x, y) => y.blockNumber - x.blockNumber || y.index - x.index);

  const tbody = $("activityTable").querySelector("tbody");
  if (!logs.length) {
    tbody.innerHTML = `<tr><td colspan="5" class="muted">No events yet — register a property to get started.</td></tr>`;
    return;
  }
  const rows = [];
  for (const ev of logs) {
    const ts = await blockTime(ev.blockNumber);
    rows.push(`<tr>
      <td>#${ev.blockNumber}</td>
      <td class="small">${fmtTime(ts)}</td>
      <td><span class="ev ev-${ev.eventName}">${ev.eventName}</span></td>
      <td>${describeEvent(ev)}</td>
      <td class="mono" title="${ev.transactionHash}">${short(ev.transactionHash)}</td>
    </tr>`);
  }
  tbody.innerHTML = rows.join("");
}

/* ---------------- property lookup ---------------- */
async function noticesFor(propertyId) {
  const events = await state.registryRead.queryFilter("NoticeIssued", 0, "latest");
  const mine = events.filter((e) => e.args.propertyId === propertyId);
  return Promise.all(
    mine.map(async (e) => {
      const n = await state.registryRead.notices(e.args.noticeId);
      return { id: e.args.noticeId, type: n.noticeType, fine: n.fine, issuedAt: n.issuedAt, paid: n.paid, paidAt: n.paidAt };
    })
  );
}

async function inspectionsFor(propertyId) {
  if (!state.inspectionRead) return [];
  const ids = await state.inspectionRead.getInspectionIds(propertyId);
  return Promise.all(ids.map(async (id) => ({ id, ...(await state.inspectionRead.inspections(id)).toObject() })));
}

async function showProperty(propertyId, silent = false) {
  const box = $("propertyResult");
  let p;
  try {
    p = await state.registryRead.getProperty(propertyId);
  } catch (e) {
    if (!silent) {
      state.currentLookup = null;
      box.className = "result empty";
      box.innerHTML = `<span class="chip chip-bad">Not registered</span>&nbsp; <strong>${escapeHtml(propertyId)}</strong> — ${escapeHtml(errMsg(e))}`;
    }
    return;
  }
  state.currentLookup = propertyId;

  const [notices, inspections] = await Promise.all([noticesFor(propertyId), inspectionsFor(propertyId)]);
  const max = state.fees ? state.fees.maxNotices : 3n;
  const blocked = p.unpaidNotices >= max;
  const isOwner = sameAddr(state.account, p.propertyOwner);

  const noticeRows = notices.length
    ? notices.map((n) => `<tr>
        <td>#${n.id}</td>
        <td>${NOTICE_TYPES[n.type]}</td>
        <td>${fmtEth(n.fine)}</td>
        <td>${n.paid ? `<span class="chip chip-ok">Paid</span>` : `<span class="chip chip-warn">Unpaid</span>`}</td>
        <td>${!n.paid && isOwner ? `<button class="btn btn-primary btn-small" data-pay="${n.id}">Pay</button>` : ""}</td>
      </tr>`).join("")
    : `<tr><td colspan="5" class="muted">No notices issued.</td></tr>`;

  const inspectionRows = inspections.length
    ? inspections.map((i) => `<tr>
        <td>#${i.id}</td>
        <td><span class="chip ${RESULT_CHIPS[i.result]}">${INSPECTION_RESULTS[i.result]}</span></td>
        <td>${escapeHtml(i.remarks || "—")}</td>
        <td>${who(i.inspector)}</td>
        <td class="small">${fmtTime(i.timestamp)}</td>
      </tr>`).join("")
    : `<tr><td colspan="5" class="muted">No inspections recorded.</td></tr>`;

  box.className = "result";
  box.innerHTML = `
    <div class="result-head">
      <h3>${escapeHtml(propertyId)}</h3>
      ${blocked
        ? `<span class="chip chip-bad">Transfer blocked · ${p.unpaidNotices} unpaid notices</span>`
        : `<span class="chip chip-ok">Clear to transfer</span>`}
    </div>
    <dl class="kv">
      <dt>Owner</dt><dd class="mono">${p.propertyOwner}${isOwner ? `<span class="chip chip-you">you</span>` : ""}</dd>
      <dt>Property type</dt><dd>${PROPERTY_TYPES[p.propertyType]} (fee ×${state.fees ? state.fees.mult[p.propertyType] : "?"})</dd>
      <dt>Registered</dt><dd>${fmtTime(p.registeredAt)}</dd>
      <dt>Transfers done</dt><dd>${p.transfersDone}</dd>
      <dt>Total fees paid</dt><dd>${fmtEth(p.totalFeesWei)}</dd>
      <dt>Unpaid notices</dt><dd>${p.unpaidNotices} <span class="muted">(limit ${max})</span></dd>
    </dl>
    <div class="subhead">Notices on this property</div>
    <table class="table compact"><thead><tr><th>ID</th><th>Type</th><th>Fine</th><th>Status</th><th></th></tr></thead>
      <tbody>${noticeRows}</tbody></table>
    <div class="subhead">Site inspections <span class="chip chip-bonus">PropertyInspection.sol</span></div>
    <table class="table compact"><thead><tr><th>ID</th><th>Result</th><th>Remarks</th><th>Inspector</th><th>Date</th></tr></thead>
      <tbody>${inspectionRows}</tbody></table>`;
}

/* ---------------- live previews ---------------- */
async function updateFeeQuote() {
  const q = $("feeQuote");
  const id = normId($("trId").value);
  if (!state.registryRead || id.length < 3) {
    q.className = "quote";
    q.textContent = "Enter a registered property ID to see the fee.";
    return;
  }
  try {
    const p = await state.registryRead.getProperty(id);
    const zone = Number($("trZone").value);
    const fee = state.fees.zone[zone] * state.fees.mult[p.propertyType];
    const blocked = p.unpaidNotices >= state.fees.maxNotices;
    const notOwner = state.account && !sameAddr(state.account, p.propertyOwner);
    q.className = `quote ${blocked || notOwner ? "bad" : "ok"}`;
    q.innerHTML =
      `Fee: <strong>${fmtEth(fee)}</strong> = ${ZONES[zone]} base ${fmtEth(state.fees.zone[zone])} × ` +
      `${PROPERTY_TYPES[p.propertyType]} ×${state.fees.mult[p.propertyType]}` +
      (blocked ? `<br/>⚠ Blocked: ${p.unpaidNotices} unpaid notices — the contract will reject this transfer.` : "") +
      (notOwner ? `<br/>⚠ Your wallet is not the current owner (${short(p.propertyOwner)}).` : "");
  } catch (_) {
    q.className = "quote bad";
    q.textContent = `${id} is not registered.`;
  }
}

async function updateNoticePreview() {
  const box = $("noticePreview");
  const raw = $("payNoticeId").value;
  if (!state.registryRead || !raw) {
    box.className = "quote";
    box.textContent = "Enter a notice number to load its details.";
    return;
  }
  const id = BigInt(raw);
  const count = await state.registryRead.noticeCount();
  if (id < 1n || id > count) {
    box.className = "quote bad";
    box.textContent = `Notice #${id} does not exist (notices issued so far: ${count}).`;
    return;
  }
  const n = await state.registryRead.notices(id);
  box.className = `quote ${n.paid ? "" : "ok"}`;
  box.innerHTML = `Notice #${id} · ${NOTICE_TYPES[n.noticeType]} on <strong>${escapeHtml(n.propertyId)}</strong><br/>` +
    `Fine <strong>${fmtEth(n.fine)}</strong> · ` +
    (n.paid ? `Already paid on ${fmtTime(n.paidAt)}` : `Unpaid since ${fmtTime(n.issuedAt)}`);
}

async function updateNoticeFine() {
  if (!state.fees) return;
  const t = Number($("ntType").value);
  $("ntFine").innerHTML = `Fine for <strong>${NOTICE_TYPES[t]}</strong>: <strong>${fmtEth(state.fees.fine[t])}</strong>`;
}

/* ---------------- forms ---------------- */
function wireForms() {
  $("connectBtn").addEventListener("click", () => connect(true));
  $("refreshBtn").addEventListener("click", refreshAll);

  // 1) register
  $("registerForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = normId($("regId").value);
    const type = Number($("regType").value);
    const rc = await sendTx(`Register ${id}`, () => state.registry.registerProperty(id, type));
    if (rc) {
      $("regId").value = "";
      $("lookupId").value = id;
      await showProperty(id);
    }
  });

  // 2) transfer (fee is read from the contract right before sending)
  $("transferForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = normId($("trId").value);
    const to = $("trTo").value.trim();
    const zone = Number($("trZone").value);
    if (!ethers.isAddress(to)) return toast("Invalid address", "The new owner must be a valid 0x wallet address.", "error");
    let fee;
    try {
      const p = await state.registryRead.getProperty(id);
      fee = (await state.registryRead.zoneBaseFee(zone)) * (await state.registryRead.typeMultiplier(p.propertyType));
    } catch (err) {
      return toast("Transfer not possible", errMsg(err), "error");
    }
    const rc = await sendTx(`Transfer ${id} (${fmtEth(fee)})`, () =>
      state.registry.transferProperty(id, to, zone, { value: fee })
    );
    if (rc) {
      $("trId").value = "";
      $("trTo").value = "";
      await updateFeeQuote();
      $("lookupId").value = id;
      await showProperty(id);
    }
  });
  $("trId").addEventListener("input", debounce(updateFeeQuote, 300));
  $("trZone").addEventListener("change", updateFeeQuote);

  // 3) pay notice
  async function payNotice(id) {
    const n = await state.registryRead.notices(id);
    return sendTx(`Pay notice #${id} (${fmtEth(n.fine)})`, () => state.registry.payNotice(id, { value: n.fine }));
  }
  $("payForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await payNotice(BigInt($("payNoticeId").value));
    } catch (err) {
      toast("Cannot pay notice", errMsg(err), "error");
    }
  });
  $("payNoticeId").addEventListener("input", debounce(updateNoticePreview, 300));
  $("propertyResult").addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-pay]");
    if (btn) await payNotice(BigInt(btn.dataset.pay));
  });

  // 4) issue notice (registrar)
  $("noticeForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = normId($("ntId").value);
    const type = Number($("ntType").value);
    const rc = await sendTx(`Issue ${NOTICE_TYPES[type]} notice on ${id}`, () => state.registry.issueNotice(id, type));
    if (rc) {
      $("lookupId").value = id;
      await showProperty(id);
    }
  });
  $("ntType").addEventListener("change", updateNoticeFine);

  // 5) lookup (view)
  $("lookupForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = normId($("lookupId").value);
    $("lookupId").value = id;
    await showProperty(id);
  });

  // Bonus: inspector management + inspections
  $("inspectorForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const addr = $("inspectorAddr").value.trim();
    if (!ethers.isAddress(addr)) return toast("Invalid address", "Enter a valid 0x wallet address.", "error");
    const rc = await sendTx(`Approve inspector ${short(addr)}`, () => state.inspection.setInspector(addr, true));
    if (rc) $("inspectorAddr").value = "";
  });
  $("inspectionForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = normId($("inspId").value);
    const result = Number($("inspResult").value);
    const remarks = $("inspRemarks").value.trim();
    const rc = await sendTx(`Record inspection on ${id}`, () => state.inspection.recordInspection(id, result, remarks));
    if (rc) {
      $("inspRemarks").value = "";
      $("lookupId").value = id;
      await showProperty(id);
    }
  });
}

window.addEventListener("DOMContentLoaded", init);
