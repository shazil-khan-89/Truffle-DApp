// Migration 1: deploy the main contract from contracts/SmartContract.sol
const PropertyRegistry = artifacts.require("PropertyRegistry");

module.exports = async function (deployer, network, accounts) {
  // The deploying account (accounts[0] in Ganache) becomes the Registrar / treasury.
  await deployer.deploy(PropertyRegistry, { from: accounts[0] });

  const registry = await PropertyRegistry.deployed();
  console.log(`   > PropertyRegistry address: ${registry.address}`);
  console.log(`   > Registrar (deployer):     ${await registry.registrar()}`);
  console.log(`   > Network:                  ${network}`);
};
