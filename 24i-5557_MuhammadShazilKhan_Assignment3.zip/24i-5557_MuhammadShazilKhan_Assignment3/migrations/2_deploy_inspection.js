// Migration 2 (bonus): deploy PropertyInspection and link it to the registry.
// PropertyInspection needs the registry address in its constructor, so this runs
// after migration 1 has finished.
const PropertyRegistry = artifacts.require("PropertyRegistry");
const PropertyInspection = artifacts.require("PropertyInspection");

module.exports = async function (deployer, network, accounts) {
  const registry = await PropertyRegistry.deployed();

  await deployer.deploy(PropertyInspection, registry.address, { from: accounts[0] });

  const inspection = await PropertyInspection.deployed();
  console.log(`   > PropertyInspection address: ${inspection.address}`);
  console.log(`   > Linked to registry:         ${await inspection.registry()}`);
};
