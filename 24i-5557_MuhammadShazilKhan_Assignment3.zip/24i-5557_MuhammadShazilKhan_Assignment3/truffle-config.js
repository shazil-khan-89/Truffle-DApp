/**
 * Truffle configuration — MG3012 Assignment 3
 * Connects Truffle to a local Ganache blockchain.
 *
 *   Ganache GUI (Quickstart):  RPC http://127.0.0.1:7545, network id 5777, chain id 1337
 *   Ganache CLI (this repo):   npm run ganache  -> same port, network id and chain id
 */
module.exports = {
  networks: {
    development: {
      host: "127.0.0.1",   // localhost
      port: 7545,          // Ganache GUI default port
      network_id: "*",     // accept any network id (Ganache GUI uses 5777)
    },
  },

  // Timeout for `truffle test`
  mocha: {
    timeout: 100000,
  },

  compilers: {
    solc: {
      version: "0.8.20",   // matches `pragma solidity ^0.8.20` in the contracts
      settings: {
        optimizer: {
          enabled: true,
          runs: 200,
        },
        // solc 0.8.20 targets "shanghai" by default, which emits the PUSH0 opcode.
        // Ganache GUI does not support PUSH0, so we target "paris" to avoid
        // "invalid opcode" errors during `truffle migrate`.
        evmVersion: "paris",
      },
    },
  },
};
