// Tiny static web server for the dApp (no extra npm packages needed).
//   npm run frontend   ->   http://localhost:3000
// Serves ./frontend and exposes Truffle's build artifacts (ABI + deployed
// addresses) at /contracts/*.json — the same idea as lite-server in the
// Truffle Pet Shop tutorial.
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, "frontend");
const ARTIFACTS_DIR = path.join(__dirname, "build", "contracts");

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

http
  .createServer((req, res) => {
    let urlPath = decodeURIComponent(req.url.split("?")[0]);
    let baseDir = FRONTEND_DIR;

    if (urlPath.startsWith("/contracts/")) {
      baseDir = ARTIFACTS_DIR;
      urlPath = urlPath.slice("/contracts".length);
    }
    if (urlPath === "/") urlPath = "/index.html";

    const filePath = path.normalize(path.join(baseDir, urlPath));
    if (!filePath.startsWith(baseDir)) {
      res.writeHead(403);
      return res.end("Forbidden");
    }

    fs.readFile(filePath, (err, data) => {
      if (err) {
        res.writeHead(404);
        return res.end("Not found");
      }
      res.writeHead(200, {
        "Content-Type": MIME[path.extname(filePath)] || "application/octet-stream",
        "Cache-Control": "no-store",
      });
      res.end(data);
    });
  })
  .listen(PORT, () => {
    console.log(`Property Registry dApp running at http://localhost:${PORT}`);
    console.log("Make sure Ganache is running and you have run `truffle migrate`.");
  });
