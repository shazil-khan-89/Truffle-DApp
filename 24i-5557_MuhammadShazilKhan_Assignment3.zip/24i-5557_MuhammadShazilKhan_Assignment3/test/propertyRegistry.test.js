// Automated tests for PropertyRegistry (SmartContract.sol) and PropertyInspection.sol
// Run with:  truffle test   (Ganache must be running on 127.0.0.1:7545)
const PropertyRegistry = artifacts.require("PropertyRegistry");
const PropertyInspection = artifacts.require("PropertyInspection");

const { toBN, toWei } = web3.utils;

// Helper: expect a transaction to revert with a specific reason string
async function expectRevert(promise, reason) {
  try {
    await promise;
  } catch (err) {
    assert(
      err.message.includes(reason),
      `Expected revert reason "${reason}" but got: ${err.message}`
    );
    return;
  }
  assert.fail(`Expected transaction to revert with "${reason}"`);
}

contract("PropertyRegistry", (accounts) => {
  const [registrar, owner, buyer, stranger] = accounts;
  let registry;

  // Fresh contract for every test so tests do not depend on each other
  beforeEach(async () => {
    registry = await PropertyRegistry.new({ from: registrar });
  });

  describe("deployment", () => {
    it("sets the deployer as registrar", async () => {
      assert.equal(await registry.registrar(), registrar);
    });

    it("loads the demo fee schedule", async () => {
      assert.equal((await registry.zoneBaseFee(0)).toString(), toWei("0.001", "ether"));
      assert.equal((await registry.zoneBaseFee(1)).toString(), toWei("0.0006", "ether"));
      assert.equal((await registry.zoneBaseFee(2)).toString(), toWei("0.0008", "ether"));
      assert.equal((await registry.typeMultiplier(2)).toNumber(), 3);
      assert.equal((await registry.noticeFine(1)).toString(), toWei("0.002", "ether"));
    });
  });

  describe("registerProperty", () => {
    it("registers a property to the caller and emits PropertyRegistered", async () => {
      const tx = await registry.registerProperty("ISB-F7-101", 1, { from: owner });
      assert.equal(tx.logs[0].event, "PropertyRegistered");
      assert.equal(tx.logs[0].args.propertyOwner, owner);

      const p = await registry.getProperty("ISB-F7-101");
      assert.equal(p.propertyOwner, owner);
      assert.equal(p.propertyType.toNumber(), 1);
      assert.equal(p.transfersDone.toNumber(), 0);
    });

    it("rejects duplicate IDs, bad ID lengths and invalid types", async () => {
      await registry.registerProperty("LHR-DHA-22", 0, { from: owner });
      await expectRevert(registry.registerProperty("LHR-DHA-22", 0, { from: buyer }), "Property already registered");
      await expectRevert(registry.registerProperty("AB", 0, { from: owner }), "Property ID must be 3-20 characters");
      await expectRevert(registry.registerProperty("X".repeat(21), 0, { from: owner }), "Property ID must be 3-20 characters");
      await expectRevert(registry.registerProperty("RWP-SAT-9", 3, { from: owner }), "Invalid property type");
    });

    it("reverts getProperty for an unregistered ID", async () => {
      await expectRevert(registry.getProperty("NOPE-000"), "Property not registered");
    });
  });

  describe("transferProperty", () => {
    beforeEach(async () => {
      await registry.registerProperty("ISB-F7-101", 1, { from: owner }); // House (x2)
    });

    it("charges zone fee x type multiplier, forwards it to the registrar and records the transfer", async () => {
      const fee = toBN(toWei("0.002", "ether")); // Islamabad 0.001 x House 2
      const before = toBN(await web3.eth.getBalance(registrar));

      const tx = await registry.transferProperty("ISB-F7-101", buyer, 0, { from: owner, value: fee });
      assert.equal(tx.logs[0].event, "PropertyTransferred");

      const after = toBN(await web3.eth.getBalance(registrar));
      assert.equal(after.sub(before).toString(), fee.toString(), "registrar should receive the exact fee");

      const p = await registry.getProperty("ISB-F7-101");
      assert.equal(p.propertyOwner, buyer);
      assert.equal(p.transfersDone.toNumber(), 1);
      assert.equal(p.totalFeesWei.toString(), fee.toString());

      const rec = await registry.transferRecords(1);
      assert.equal(rec.from, owner);
      assert.equal(rec.to, buyer);
      assert.equal((await registry.transferCount()).toNumber(), 1);
    });

    it("rejects a wrong fee, a non-owner and an invalid new owner", async () => {
      const fee = toWei("0.002", "ether");
      await expectRevert(registry.transferProperty("ISB-F7-101", buyer, 0, { from: owner, value: toWei("0.001", "ether") }), "Incorrect transfer fee");
      await expectRevert(registry.transferProperty("ISB-F7-101", buyer, 0, { from: stranger, value: fee }), "Only the current owner can transfer");
      await expectRevert(registry.transferProperty("ISB-F7-101", owner, 0, { from: owner, value: fee }), "Invalid new owner address");
      await expectRevert(registry.transferProperty("ISB-F7-101", buyer, 3, { from: owner, value: fee }), "Invalid zone");
    });
  });

  describe("notices and the no-dues rule", () => {
    beforeEach(async () => {
      await registry.registerProperty("RWP-SAT-9", 0, { from: owner }); // Plot (x1)
    });

    it("only lets the registrar issue notices", async () => {
      await expectRevert(registry.issueNotice("RWP-SAT-9", 0, { from: stranger }), "Only the registrar can issue notices");
      await registry.issueNotice("RWP-SAT-9", 0, { from: registrar });
      const p = await registry.getProperty("RWP-SAT-9");
      assert.equal(p.unpaidNotices.toNumber(), 1);
    });

    it("lets the owner pay the exact fine once", async () => {
      await registry.issueNotice("RWP-SAT-9", 2, { from: registrar }); // Encroachment 0.0005
      const fine = toWei("0.0005", "ether");

      await expectRevert(registry.payNotice(1, { from: stranger, value: fine }), "Only the property owner can pay this notice");
      await expectRevert(registry.payNotice(1, { from: owner, value: toWei("0.001", "ether") }), "Incorrect fine amount");

      const tx = await registry.payNotice(1, { from: owner, value: fine });
      assert.equal(tx.logs[0].event, "NoticePaid");
      assert.equal((await registry.notices(1)).paid, true);
      assert.equal((await registry.getProperty("RWP-SAT-9")).unpaidNotices.toNumber(), 0);

      await expectRevert(registry.payNotice(1, { from: owner, value: fine }), "Notice already paid");
      await expectRevert(registry.payNotice(99, { from: owner, value: fine }), "Notice does not exist");
    });

    it("blocks transfers at 3 unpaid notices and unblocks after one is paid", async () => {
      for (let i = 0; i < 3; i++) await registry.issueNotice("RWP-SAT-9", 0, { from: registrar });
      const fee = toWei("0.0006", "ether"); // Rawalpindi 0.0006 x Plot 1

      await expectRevert(
        registry.transferProperty("RWP-SAT-9", buyer, 1, { from: owner, value: fee }),
        "Too many unpaid notices"
      );

      await registry.payNotice(1, { from: owner, value: toWei("0.001", "ether") });
      await registry.transferProperty("RWP-SAT-9", buyer, 1, { from: owner, value: fee });
      assert.equal((await registry.getProperty("RWP-SAT-9")).propertyOwner, buyer);
    });
  });
});

contract("PropertyInspection (bonus contract)", (accounts) => {
  const [registrar, owner, inspector, stranger] = accounts;
  let registry;
  let inspection;

  beforeEach(async () => {
    registry = await PropertyRegistry.new({ from: registrar });
    inspection = await PropertyInspection.new(registry.address, { from: registrar });
    await registry.registerProperty("LHR-GUL-7", 2, { from: owner });
  });

  it("is linked to the registry and uses its registrar for access control", async () => {
    assert.equal(await inspection.registry(), registry.address);
    await expectRevert(inspection.setInspector(inspector, true, { from: stranger }), "Only the registrar can manage inspectors");
    await inspection.setInspector(inspector, true, { from: registrar });
    assert.equal(await inspection.isInspector(inspector), true);
  });

  it("records an inspection after checking the property in the registry", async () => {
    await inspection.setInspector(inspector, true, { from: registrar });
    const tx = await inspection.recordInspection("LHR-GUL-7", 1, "Boundary wall needs repair", { from: inspector });
    assert.equal(tx.logs[0].event, "InspectionRecorded");

    const rec = await inspection.inspections(1);
    assert.equal(rec.inspector, inspector);
    assert.equal(rec.ownerAtInspection, owner, "owner snapshot comes from the registry");
    assert.equal(rec.result.toNumber(), 1);

    const ids = await inspection.getInspectionIds("LHR-GUL-7");
    assert.deepEqual(ids.map((x) => x.toNumber()), [1]);
  });

  it("rejects unapproved inspectors and unregistered properties", async () => {
    await expectRevert(inspection.recordInspection("LHR-GUL-7", 0, "ok", { from: stranger }), "Only an approved inspector");
    // Revert reason bubbles up from PropertyRegistry.getProperty (cross-contract call)
    await expectRevert(inspection.recordInspection("FAKE-123", 0, "ok", { from: registrar }), "Property not registered");
  });
});
